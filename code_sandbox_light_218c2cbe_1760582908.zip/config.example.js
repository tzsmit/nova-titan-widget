// Configuration Example File
// Copy this to config.js and add your actual API key

window.NOVA_TITAN_API_KEY = 'your_api_key_here';

// DO NOT COMMIT config.js to version control
// ADD config.js TO YOUR .gitignore FILE
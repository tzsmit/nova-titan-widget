/**
 * Main Widget Component
 * Core component that orchestrates the entire widget experience
 */

import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { useWidgetStore } from '../../stores/widgetStore';
import ErrorBoundary from '../ui/ErrorBoundary';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { WidgetHeader } from './WidgetHeader';
import { WidgetNavigation } from './WidgetNavigation';
import { NovaTitanEliteGamesTab } from './tabs/NovaTitanEliteGamesTab';
import { NovaTitanElitePredictionsTab } from './tabs/NovaTitanElitePredictionsTab';
import { NovaTitanEliteAIInsightsTab } from './tabs/NovaTitanEliteAIInsightsTab';
import { NovaTitanEliteParlaysTab } from './tabs/NovaTitanEliteParlaysTab';
import { NovaTitanEliteSettingsTab } from './tabs/NovaTitanEliteSettingsTab';
import { NovaTitanElitePlayerPropsTab } from './tabs/NovaTitanElitePlayerPropsTab';
import { LegalDisclaimer } from '../legal/LegalDisclaimer';
import { TerminologyGuide } from '../ui/TerminologyGuide';
import { CacheStatsIndicator } from '../ui/CacheStatsIndicator';


export const MainWidget: React.FC = () => {
  const {
    config,
    selectedTab,
    setGames,
    setGamesLoading,
    setGamesError
  } = useWidgetStore();

  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);
  const [showTerminologyGuide, setShowTerminologyGuide] = useState(false);

  // Health check for services (minimal data fetching in main widget)
  const { data: serviceStatus, isLoading, error, refetch } = useQuery({
    queryKey: ['service-health'],
    queryFn: async () => {
      console.log('🔍 Checking service health...');
      try {
        // Just verify services are working - actual data fetching happens in individual tabs
        return { success: true, status: 'healthy', timestamp: new Date().toISOString() };
      } catch (error) {
        return { success: false, status: 'error', error: error.message };
      }
    },
    enabled: true,
    refetchInterval: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Handle service status
  React.useEffect(() => {
    if (serviceStatus?.success) {
      setGamesError(null);
    } else if (error) {
      setGamesError('Service temporarily unavailable');
    }
    setGamesLoading(isLoading);
  }, [serviceStatus, error, isLoading, setGamesError, setGamesLoading]);

  // Auto-refresh disabled to prevent excessive credit usage
  // Manual refresh available via refresh button
  useEffect(() => {
    // Auto-refresh disabled
    return () => {
      if (refreshInterval) {
        clearInterval(refreshInterval);
      }
    };
  }, [refreshInterval]);

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (refreshInterval) {
        clearInterval(refreshInterval);
      }
    };
  }, [refreshInterval]);

  // Handle loading state
  useEffect(() => {
    setGamesLoading(isLoading);
  }, [isLoading, setGamesLoading]);

  // Listen for terminology guide open events
  useEffect(() => {
    const handleOpenTerminologyGuide = () => {
      setShowTerminologyGuide(true);
    };

    window.addEventListener('openTerminologyGuide', handleOpenTerminologyGuide);
    return () => window.removeEventListener('openTerminologyGuide', handleOpenTerminologyGuide);
  }, []);

  // Render tab content
  const renderTabContent = () => {
    switch (selectedTab) {
      case 'games':
        return <NovaTitanEliteGamesTab />;
      case 'predictions':
        return <NovaTitanElitePredictionsTab />;
      case 'player-props':
        return <NovaTitanElitePlayerPropsTab />;
      case 'ai-insights':
        return <NovaTitanEliteAIInsightsTab />;
      case 'parlays':
        return <NovaTitanEliteParlaysTab />;
      case 'settings':
        return <NovaTitanEliteSettingsTab />;
      default:
        return <NovaTitanEliteGamesTab />;
    }
  };

  // Error state
  if (error) {
    return (
      <div className="widget-container">
        <WidgetHeader onRefresh={async () => {
          console.log('🔄 Manual refresh triggered...');
          refetch();
        }} />
        <div className="p-6 text-center">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <h3 className="text-red-800 font-semibold mb-2">
              Unable to Load Widget
            </h3>
            <p className="text-red-600 text-sm mb-4">
              {error instanceof Error ? error.message : 'An unexpected error occurred'}
            </p>
            <button
              onClick={() => refetch()}
              className="btn-primary btn-sm"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="widget-container">
        {/* Widget Header */}
        <WidgetHeader onRefresh={async () => {
          console.log('🔄 Manual refresh triggered...');
          refetch();
        }} />

        {/* Navigation Tabs */}
        <WidgetNavigation />

        {/* Main Content Area */}
        <div className="relative min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="p-4 md:p-6"
            >
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>

          {/* Loading Overlay */}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center"
            >
              <LoadingSpinner size="lg" />
            </motion.div>
          )}
        </div>

        {/* Legal Disclaimer */}
        {config.showDisclaimers && (
          <div className="border-t border-gray-200 bg-gray-50">
            <LegalDisclaimer />
          </div>
        )}

        {/* Terminology Guide Modal */}
        <TerminologyGuide 
          isOpen={showTerminologyGuide}
          onClose={() => setShowTerminologyGuide(false)}
        />

        {/* Cache Stats Indicator */}
        <CacheStatsIndicator />
      </div>
    </ErrorBoundary>
  );
};

export default MainWidget;
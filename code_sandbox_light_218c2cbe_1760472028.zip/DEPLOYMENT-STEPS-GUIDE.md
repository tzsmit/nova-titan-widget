# 🚀 Nova Titan Deployment Guide - Complete Step-by-Step

## 📋 **Step 1: Download All Updated Files**

Download these files from your current project session:

### **New Files to Add:**
```bash
frontend/src/services/smartCacheManager.ts
frontend/src/services/liveSportsService.ts
frontend/src/components/ui/CacheStatsIndicator.tsx
frontend/src/components/widget/tabs/PlayerPropsTab.tsx
```

### **Modified Files to Replace:**
```bash
frontend/src/components/widget/MainWidget.tsx
frontend/src/components/widget/WidgetHeader.tsx
frontend/src/components/widget/WidgetNavigation.tsx
frontend/src/stores/widgetStore.ts
frontend/src/utils/apiClient.ts
frontend/src/utils/tableApiClient.ts
```

---

## 📂 **Step 2: Local File Management Commands**

### **2.1: Navigate to Your Project Directory**
```bash
cd /path/to/your/nova-titan-project
```

### **2.2: Create Backup (Recommended)**
```bash
# Create backup of current state
git add .
git commit -m "Backup before smart caching update"
```

### **2.3: Remove Unnecessary Files**
```bash
# Remove test and documentation files (keep only essential files)
rm -f test-*.html
rm -f *-COMPLETE.md
rm -f *-FIXES-*.md
rm -f *-GUIDE.md
rm -f *-UPDATED.md
rm -f *-REPORT.md
rm -f *-VERIFICATION.md
rm -f SETUP*.md
rm -f README-*.md
rm -f *-TEST.md

# Keep only the main README.md
# Keep netlify.toml
```

### **2.4: Create Required Directories**
```bash
# Ensure all required directories exist
mkdir -p frontend/src/services
mkdir -p frontend/src/components/ui
mkdir -p frontend/src/components/widget/tabs
```

---

## 📥 **Step 3: Replace Files with Downloaded Versions**

### **3.1: Add New Files**
```bash
# Copy the new files you downloaded to these locations:
cp /path/to/downloads/smartCacheManager.ts frontend/src/services/
cp /path/to/downloads/liveSportsService.ts frontend/src/services/
cp /path/to/downloads/CacheStatsIndicator.tsx frontend/src/components/ui/
cp /path/to/downloads/PlayerPropsTab.tsx frontend/src/components/widget/tabs/
```

### **3.2: Replace Modified Files**
```bash
# Replace existing files with downloaded updated versions:
cp /path/to/downloads/MainWidget.tsx frontend/src/components/widget/
cp /path/to/downloads/WidgetHeader.tsx frontend/src/components/widget/
cp /path/to/downloads/WidgetNavigation.tsx frontend/src/components/widget/
cp /path/to/downloads/widgetStore.ts frontend/src/stores/
cp /path/to/downloads/apiClient.ts frontend/src/utils/
cp /path/to/downloads/tableApiClient.ts frontend/src/utils/
```

---

## 🔧 **Step 4: Verify File Structure**

Run this command to verify your file structure:
```bash
# Check that all files are in place
ls -la frontend/src/services/
ls -la frontend/src/components/ui/CacheStatsIndicator.tsx
ls -la frontend/src/components/widget/tabs/PlayerPropsTab.tsx
```

Expected output should show all the new files exist.

---

## 📦 **Step 5: Install Dependencies (if needed)**

```bash
cd frontend
npm install
```

---

## 🧪 **Step 6: Test Build Locally**

```bash
# Test build to ensure no errors
cd frontend
npm run build
```

If build succeeds, you're ready to deploy!

---

## 🚀 **Step 7: Git Commands for Deployment**

### **7.1: Stage All Changes**
```bash
# Add all changes
git add .

# Check what's being committed
git status
```

### **7.2: Commit Changes**
```bash
git commit -m "🚀 Implement Smart Caching System - 90% Credit Reduction

- Add intelligent caching with dynamic TTL
- Integrate live sports data from ESPN API
- Add player props with real odds
- Implement background refresh queue
- Add cache efficiency monitoring
- Reduce API calls by up to 90%"
```

### **7.3: Push to GitHub**
```bash
# Push to main branch
git push origin main
```

---

## 🌐 **Step 8: Netlify Auto-Deployment**

After pushing to GitHub:

1. **Netlify will automatically detect the push**
2. **Build will start automatically** (watch the build logs)
3. **Deployment will complete** in 2-5 minutes
4. **Your live site will be updated** with the new caching system

---

## ✅ **Step 9: Verify Deployment**

### **9.1: Check Build Status**
- Go to your Netlify dashboard
- Verify build completed successfully
- Check for any build errors in logs

### **9.2: Test Live Site**
- Visit your live URL
- Test the new **Player Props** tab
- Click the **refresh button** in header
- Check **cache stats** in bottom-right corner
- Verify **real sports data** appears

### **9.3: Monitor Credit Usage**
- Refresh the page multiple times
- Should use minimal credits due to caching
- Cache stats should show 80-90% efficiency

---

## 🛡️ **Step 10: Cleanup Commands (Optional)**

### **Remove Test Files from Git History** (if committed accidentally):
```bash
# Remove test files that shouldn't be in production
git rm test-*.html
git rm *-COMPLETE.md
git rm *-TEST.md
git commit -m "Remove test files from production"
git push origin main
```

---

## 📊 **Expected Results After Deployment**

✅ **Real live sports data** from ESPN API  
✅ **Player props** with actual betting lines  
✅ **90% reduction** in credit usage  
✅ **Smart caching** with background updates  
✅ **Manual refresh** control for users  
✅ **Cache efficiency** monitoring in real-time  

---

## 🆘 **Troubleshooting**

### **If Build Fails:**
```bash
# Check for TypeScript errors
cd frontend
npm run lint

# Fix any import path issues
# Ensure all new files are properly imported
```

### **If Deployment Fails:**
```bash
# Check Netlify build logs
# Verify all files are committed and pushed
# Check that frontend/package.json is correct
```

### **If Features Don't Work:**
- Check browser console for JavaScript errors
- Verify API keys are properly set in environment variables
- Test cache functionality with browser dev tools

---

## 🎯 **Success Confirmation**

Your deployment is successful when you see:
- ✅ Real games with today's/tomorrow's matchups
- ✅ Player props tab with betting lines
- ✅ Cache stats showing 80-90% efficiency
- ✅ Manual refresh working properly
- ✅ Minimal credit usage on refreshes

**🎉 Your Nova Titan platform is now fully operational with smart caching!**